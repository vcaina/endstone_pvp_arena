from endstone_pvp_arena.pvp_arena import PvPArena

__all__ = ["PvPArena"]